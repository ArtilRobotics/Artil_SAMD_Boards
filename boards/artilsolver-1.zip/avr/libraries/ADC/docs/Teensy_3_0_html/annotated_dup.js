var annotated_dup =
[
    [ "ADC", "class_a_d_c.html", "class_a_d_c" ],
    [ "ADC_Module", "class_a_d_c___module.html", "class_a_d_c___module" ]
];