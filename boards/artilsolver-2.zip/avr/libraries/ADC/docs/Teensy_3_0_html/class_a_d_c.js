var class_a_d_c =
[
    [ "ADC", "class_a_d_c.html#a60b6e21403b1f30984f63832c0562960", null ],
    [ "analogRead", "class_a_d_c.html#a4196bada3d9d28af2604175a8a79d872", null ],
    [ "analogRead", "class_a_d_c.html#aaf6079870b115d8b029d3613d44091dd", null ],
    [ "analogReadContinuous", "class_a_d_c.html#a749efc928425a1eea18341ccfafd1819", null ],
    [ "analogReadDifferential", "class_a_d_c.html#aec3464cdb697f89cf162813b00b2e965", null ],
    [ "readSingle", "class_a_d_c.html#aee7423bfcbb03465bb0bd1e3c6474452", null ],
    [ "resetError", "class_a_d_c.html#aa65014de31051e06a469982ca286496b", null ],
    [ "startContinuous", "class_a_d_c.html#ad592f87ec644457b5056ae41c645ac0a", null ],
    [ "startContinuousDifferential", "class_a_d_c.html#ae6179fc2e5ca7de1b0a3eb1f36985885", null ],
    [ "startSingleDifferential", "class_a_d_c.html#ac1016c1d107118a0064c2b627dbd831b", null ],
    [ "startSingleRead", "class_a_d_c.html#a113479488fae5f5407f884dd95fbec72", null ],
    [ "stopContinuous", "class_a_d_c.html#a436e52cf82ca735f636899de670a2f0c", null ],
    [ "adc", "class_a_d_c.html#a03e1c7f64c02dec1976810a0a4967cf2", null ],
    [ "adc0", "class_a_d_c.html#a0d5b4dd16bbb03082daeeaadafec2474", null ],
    [ "channel2sc1aADC0", "class_a_d_c.html#ae873ea32d672d2d3ea1549fa0ec50f97", null ],
    [ "diff_table_ADC0", "class_a_d_c.html#a1b2c46ade5591fb8038961fb352506a3", null ],
    [ "sc1a2channelADC0", "class_a_d_c.html#a4377c680975fe754de24b8f8617042de", null ]
];