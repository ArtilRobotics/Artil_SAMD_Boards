// This header file is in the public domain.

#ifndef CORE_TEENSY
#define CORE_TEENSY
#endif
